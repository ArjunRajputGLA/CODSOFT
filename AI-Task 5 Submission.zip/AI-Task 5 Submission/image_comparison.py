import cv2
import face_recognition
import os

photo_path_1 = "Dinesh Photos/Dinesh.jpg"
photo_path_2 = "Dinesh Photos/Old Memory-Enhanced.jpg"

def read_and_process_image(image_path):
    if not os.path.exists(image_path):
        print(f"Error: File '{image_path}' does not exist.")
        return None, None
    img = cv2.imread(image_path)
    if img is None:
        print(f"Error: Could not read image '{image_path}'.")
        return None, None
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img, rgb_img

img1, rgb_img1 = read_and_process_image(photo_path_1)
if rgb_img1 is None:
    exit(1)

img2, rgb_img2 = read_and_process_image(photo_path_2)
if rgb_img2 is None:
    exit(1)

img_encoding1 = face_recognition.face_encodings(rgb_img1)[0]
img_encoding2 = face_recognition.face_encodings(rgb_img2)[0]

result = face_recognition.compare_faces([img_encoding1], img_encoding2)
if result == [True]:
    print("Both photos match")
else:
    print("Both photos are different")